# voicevox - errors

class HttpException(Exception):
    pass


class NotfoundError(HttpException):
    pass
